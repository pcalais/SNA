

g++ -std=c++0x -pthread ppr.cpp -o ppr

